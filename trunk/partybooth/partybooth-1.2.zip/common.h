#ifndef COMMON_H
#define	COMMON_H
#ifndef __AVR_ATtiny13__
#define __AVR_ATtiny13__
#endif
#endif	/* COMMON_H */
